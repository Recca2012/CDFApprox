############################################################
###File with functions and packages#########################
############################################################



############################################################
####Packages################################################
############################################################
#require(mvtnorm)
#require(mvPot)
#require(doParallel)
#require(foreach)
#require(Rcpp)
############################################################
############################################################
############################################################





############################################################
###R functions##############################################
############################################################

###Function to calculate conditional probability############
############################################################
px2 <- function(X=M[length(M)],M,Sigma,Y=M[-length(M)],p,lattice1,lattice2){
  val <- log(mvPot::mvtNormQuasiMonteCarlo(lattice1$primeP, c(Y,X), Sigma, lattice1$genVec)[[1]])-#log(pmvnorm(mean = M,sigma = Sigma,lower = -Inf,upper = c(Y,X))[1:1])-
    log(mvPot::mvtNormQuasiMonteCarlo(lattice2$primeP, c(Y), Sigma[-c((length(M)-length(X)+1):length(M)),-c((length(M)-length(X)+1):length(M))], lattice2$genVec)[[1]])#log(pmvnorm(mean = M[-length(M)],sigma = Sigma[-length(M),-length(M)],lower = -Inf,upper = Y)[1:1])

  return(exp(val))
}
###Function to calculate joint probability using 1 by 1 ####
###sequential for function##################################
############################################################
pmvNorm2 <- function(M,Sigma,Corr,upper=M,use=3,lattice){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  dens <- numeric(length = length(M))

  dens[1] <- pnorm(q = upper[1],mean = M[1],sd = sqrt(Sigma[1,1]),log.p = T)
  dens[2] <- (log(pmvnorm(mean = M[1:2],sigma = Sigma[1:2,1:2],lower = -Inf,upper = c(upper[1],upper[2]))[1])-
                pnorm(q = upper[1],mean = M[1],sd = sqrt(Sigma[1,1]),log.p = T))
  for(i in 3:use){

    dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  }
  latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  for(i in (use+1):length(M)){
    points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
    Sigma2 <- Sigma[c(points,i),c(points,i)]
    M2 <- M[c(points,i)]
    dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  }

  dens2 <- sum(dens)
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###sequential for function##################################
############################################################
pmvNorm3 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                        cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint
  for(i in 2:(runs)){
    to.use <- ((i-1)*joint+1):min(i*joint,length(M))
    points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
      order(Corr[x,-c(((i-1)*joint+1):length(M))],decreasing = T)[1:min(used,use)]
    }))
    points <- unique(as.vector(points))
    dens[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                       lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
    used <- max(to.use)
  }

  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens)
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###parallel for function####################################
############################################################
pmvNorm4 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                               cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint


  RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
  Nrow <- 1:nrow(RUNS)
  RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




  teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
    dens2 <- numeric(length = length(RUNS[,j]))
    for(i in 1:length(RUNS[,j])){
      if(!is.na(RUNS[i,j])){
        to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
        points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
          order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
        }))
        points <- unique(as.vector(points))
        dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                            lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
        used <- max(to.use)
      }

    }
    return(dens2)
  }


  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens[1],do.call(what = c,args = teste))
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###parallel for function####################################
############################################################
pmvNorm4.2 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  if(joint>1){
    runs <- ceiling(length(M)/joint)
    dens <- numeric(length = runs)

    dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                                 cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
    used <- joint


    RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
    Nrow <- 1:nrow(RUNS)
    RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




    teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
      dens2 <- numeric(length = length(RUNS[,j]))
      for(i in 1:length(RUNS[,j])){
        if(!is.na(RUNS[i,j])){
          to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
          points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
            order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
          }))
          points <- unique(as.vector(points))
          dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                              lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
          used <- max(to.use)
        }

      }
      return(dens2)
    }


    dens2 <- sum(dens[1],do.call(what = c,args = teste))
    return((dens2))
  }
  if(joint==1){
    runs <- ceiling(length(M)/joint)
    dens <- numeric(length = runs)

    dens[1] <- pnorm(q = upper[1:joint],sd = Sigma[1:joint,1:joint],log.p = T)
    dens[2] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:2*joint]),
                                                 cov = Sigma[1:2*joint,1:2*joint], genVec = lattice[[2*joint-1]]$genVec)[[1]])-
      dens[1]
    used <- joint


    RUNS <- matrix(data = c(3:runs,rep(NA_real_,l=(cores-length(3:runs)%%cores))),ncol = cores,byrow = T)
    Nrow <- 1:nrow(RUNS)
    RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




    teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
      dens2 <- numeric(length = length(RUNS[,j]))
      for(i in 1:length(RUNS[,j])){
        if(!is.na(RUNS[i,j])){
          to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
          points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
            order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
          }))
          points <- unique(as.vector(points))
          dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                              lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
          used <- max(to.use)
        }

      }
      return(dens2)
    }


    dens2 <- sum(dens[1],do.call(what = c,args = teste))
    return((dens2))
  }


}
###Function to calculate joint probability using n by n ####
###parallel for function####################################
############################################################
pmvNorm6 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                               cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint


  RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
  Nrow <- 1:nrow(RUNS)
  RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




  teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
    dens2 <- numeric(length = length(RUNS[,j]))
    for(i in 1:length(RUNS[,j])){
      if(!is.na(RUNS[i,j])){
        to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
        points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
          #order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
          sample(x = min(to.use)-1,size = min(min(to.use)-1,use))

        }))
        points <- unique(as.vector(points))
        dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                            lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
        used <- max(to.use)
      }

    }
    return(dens2)
  }


  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens[1],do.call(what = c,args = teste))
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###parallel for function####################################
############################################################
pmvNorm7 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                               cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint


  RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
  Nrow <- 1:nrow(RUNS)
  RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




  teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
    dens2 <- numeric(length = length(RUNS[,j]))
    for(i in 1:length(RUNS[,j])){
      if(!is.na(RUNS[i,j])){
        to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
        # points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
        #   #order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
        #   sample(x = min(to.use)-1,size = min(min(to.use)-1,use))
        #
        # }))
        # points <- unique(as.vector(points))
        points <- sample(x = min(to.use)-1,size = min(min(to.use)-1,use))
        dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                            lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
        used <- max(to.use)
      }

    }
    return(dens2)
  }


  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens[1],do.call(what = c,args = teste))
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###parallel for function####################################
############################################################
pmvNorm8 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores,neigbors){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                               cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint


  RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
  Nrow <- 1:nrow(RUNS)
  RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]




  teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
    dens2 <- numeric(length = length(RUNS[,j]))
    for(i in 1:length(RUNS[,j])){
      if(!is.na(RUNS[i,j])){
        to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
        # points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
        #   order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
        # }))
        points <- unique(as.vector(neigbors[to.use,]))[-which(unique(as.vector(neigbors[to.use,]))%in%c(to.use,NA))]
        dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                            lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
        used <- max(to.use)
      }

    }
    return(dens2)
  }


  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens[1],do.call(what = c,args = teste))
  return((dens2))
}
###Function to calculate joint probability using n by n ####
###parallel for function#################################### Loading inside nodes
############################################################
pmvNorm9.2 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores,
                       file.Sigma,file.Corr,file.M,file.Upper){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  if(joint>1){
    runs <- ceiling(length(M)/joint)
    dens <- numeric(length = runs)

    dens[1] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                                 cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
    used <- joint


    RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=(cores-length(2:runs)%%cores))),ncol = cores,byrow = T)
    Nrow <- 1:nrow(RUNS)
    RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]
    remove(M,Sigma,Corr,upper)



    teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
      load(file.Sigma)
      load(file.Corr)
      load(file.M)
      load(file.Upper)
      dens2 <- numeric(length = length(RUNS[,j]))
      for(i in 1:length(RUNS[,j])){
        if(!is.na(RUNS[i,j])){
          to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
          points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
            order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
          }))
          points <- unique(as.vector(points))
          dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                              lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
          used <- max(to.use)
        }

      }
      return(dens2)
    }

    if(sum(is.infinite(do.call(what = c,args = teste)))>0){
      return(-Inf)
    }
    dens2 <- sum(dens[1],do.call(what = c,args = teste))
    return((dens2))
  }
  if(joint==1){
    runs <- ceiling(length(M)/joint)
    dens <- numeric(length = runs)

    dens[1] <- pnorm(q = upper[1:joint],sd = Sigma[1:joint,1:joint],log.p = T)
    dens[2] <- log(mvPot::mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:2*joint]),
                                                 cov = Sigma[1:2*joint,1:2*joint], genVec = lattice[[2*joint-1]]$genVec)[[1]])-
      dens[1]
    used <- joint


    RUNS <- matrix(data = c(3:runs,rep(NA_real_,l=(cores-length(3:runs)%%cores))),ncol = cores,byrow = T)
    Nrow <- 1:nrow(RUNS)
    RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]
    remove(M,Sigma,Corr,upper)




    teste <- foreach::foreach(j=1:cores,.packages = c("CDFNormalAproxPackNoC","mvPot")) %dopar% {
      load(file.Sigma)
      load(file.Corr)
      load(file.M)
      load(file.Upper)
      dens2 <- numeric(length = length(RUNS[,j]))
      for(i in 1:length(RUNS[,j])){
        if(!is.na(RUNS[i,j])){
          to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
          points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
            order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
          }))
          points <- unique(as.vector(points))
          dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                              lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
          used <- max(to.use)
        }

      }
      return(dens2)
    }


    dens2 <- sum(dens[1],do.call(what = c,args = teste))
    return((dens2))
  }


}




#' Joint Distribution n by n
#' Calculate the joint distribution in parallel n by n
#' @param M vector of means
#' @param Sigma matrix of covariance functions
#' @param Corr matrix of correlations
#' @param upper upper limit for the multivariate distribution
#' @param use Number of neighbors being used
#' @param joint Number of observations to calculate simultaneously
#' @param lattice list of lattice for calculation, starting at 2 and going until use:joint+joint
#' @param cores Number of cores to do parallel computing
#' @export
#' @return A single value, the joint probability
#'
pmvNorm5 <- function(M,Sigma,Corr,upper=M,use=3,joint=4,lattice,cores){
  # Corr <- cov2cor(Sigma)#(diag(diag(Sigma)^(-0.5)))%*%Sigma%*%(diag(diag(Sigma)^(-0.5)))
  runs <- ceiling(length(M)/joint)
  dens <- numeric(length = runs)

  dens[1] <- log(mvtNormQuasiMonteCarlo(lattice[[1]]$primeP,(upper[1:joint]),
                                        cov = Sigma[1:joint,1:joint], genVec = lattice[[joint-1]]$genVec)[[1]])
  used <- joint


  RUNS <- matrix(data = c(2:runs,rep(NA_real_,l=cores-length(2:runs)%%cores)),ncol = cores,byrow = T)
  Nrow <- 1:nrow(RUNS)
  RUNS[which(Nrow%%2==0),] <- RUNS[which(Nrow%%2==0),cores:1]


  clusterExport(cl = cl,list = list("joint","M","Corr","use","upper","p","lattice","px2","Sigma"))
  teste <- parApply(cl = cl,X = RUNS,MARGIN = 2,FUN = function(Y){
    dens2 <- numeric(length = length(Y))
    for(i in 1:length(Y)){
      if(!is.na(Y[i])){
        to.use <- ((Y[i]-1)*joint+1):min(Y[i]*joint,length(M))
        points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
          order(Corr[x,-c(((Y[i]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
        }))
        points <- unique(as.vector(points))
        dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
                            lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
        used <- max(to.use)
      }

    }
    return(dens2)
  })

  # teste <- foreach(j=1:cores) %dopar% {
  #   dens2 <- numeric(length = length(RUNS[,j]))
  #   for(i in 1:length(RUNS[,j])){
  #     if(!is.na(RUNS[i,j])){
  #       to.use <- ((RUNS[i,j]-1)*joint+1):min(RUNS[i,j]*joint,length(M))
  #       points <- t(apply(X = matrix(to.use),MARGIN = 1,FUN = function(x){
  #         order(Corr[x,-c(((RUNS[i,j]-1)*joint+1):length(M))],decreasing = T)[1:min(min(to.use)-1,use)]
  #       }))
  #       points <- unique(as.vector(points))
  #       dens2[i] <- log(px2(X =upper[to.use] ,M = M[c(points,to.use)],Sigma = Sigma[c(points,to.use),c(points,to.use)],Y = upper[points],p=p,
  #                           lattice1 = lattice[[length(points)-1+length(to.use)]],lattice2 = lattice[[length(points)-1]]))
  #       used <- max(to.use)
  #     }
  #
  #   }
  #   return(dens2)
  # }


  # for(i in 2:min(use)){
  #
  #   dens[i] <- log(px2(X =upper[i] ,M = M[1:i],Sigma = Sigma[1:i,1:i],Y = upper[1:(i-1)],p=p,lattice1 = lattice[[1]][[i-2]],lattice2 = lattice[[2]][[i-2]]))
  # }
  # latticeRule1 <- lattice[[1]][[length(lattice[[1]])]]
  # latticeRule2 <- lattice[[2]][[length(lattice[[2]])]]
  # for(i in (use+1):length(M)){
  #   points <- order(Corr[i,-c(i:length(M))],decreasing = T)[1:use]#which(Corr[i,-c(i:length(M))]>=sort(x = Corr[i,-c(i:length(M))],decreasing = T)[use])
  #   Sigma2 <- Sigma[c(points,i),c(points,i)]
  #   M2 <- M[c(points,i)]
  #   dens[i] <- log(px2(X =upper[i] ,M = M2,Sigma = Sigma2,Y = upper[points],p=p,lattice1 = latticeRule1,lattice2 = latticeRule2))
  # }

  dens2 <- sum(dens[1],teste)
  return((dens2))
}





############################################################
###C functions##############################################
############################################################
#sourceCpp("/storage/work/m/mfn120/research/CDFNormalApprox/code/function/CppFunction.cpp")


